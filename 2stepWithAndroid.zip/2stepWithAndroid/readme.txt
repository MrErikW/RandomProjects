This is a simple projects that tries to recreate a functional 2step verification process with a mobile phone. 
The required items are { A functional SIMcard with the ability to use SMS, Macrodroid application from the google play store }
After you have all of the needed stuff create a webhook in macrodroid that sends an sms when triggered and make to variables called number and verifycode.
When that's done then just use the website address given and insert it inside the python script where needed. 
If that's all done then it should work.
[[ The default login credentials are test and test ]]